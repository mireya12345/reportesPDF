/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Turno.DAO;

import Turno.modelos.Turno;
import UI.Turno.UIConexion;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author mireya
 */
public class TurnoDAO extends UIConexion{   
    public ArrayList<Turno> listar() {
        ArrayList<Turno> Turnos = new ArrayList();

        try (java.sql.Connection connection = connectToDB()) {
            String query = "SELECT * FROM Turno"; //sentencia
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                Turno hora= new Turno(
                        Integer.valueOf(rs.getString("ID")),
                        rs.getString("horainicio"),
                        rs.getString("horasalida"),  
                        rs.getString("descripcion")
                );
              
                Turnos.add(hora);
            }
        } catch (SQLException e) {
            System.out.println("" + e.getMessage());
            // TODO: handle exception
        }
        return Turnos;
    }
    //Guardar un nuevo Turno
    public void insertarTurno(Turno turno) {
        try (java.sql.Connection connection = connectToDB()) {
            PreparedStatement ps = null;
            //Statement statement = connection.createStatement();
            String query = "insert into Turno (horainicio, horasalida,descripcion) values (?,?,?)";
            ps = connection.prepareStatement(query);
            // requisitos que me pidio 
            
            ps.setString(1, turno.getHoraInicio());
             ps.setString(2, turno.getHoraSalida());
            ps.setString(3, turno.getDescripcion());
              
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
               //Actualizar  un Turno
    public void actualizarTurno(Turno turno) {
        try (java.sql.Connection connection = connectToDB()) {
            PreparedStatement ps = null;
            //Statement statement = connection.createStatement();
            String query = "update turno set horainicio = ? ,horasalida = ?,descripcion where id =?"; //ojo no olvidarsse del where
            ps = connection.prepareStatement(query);
            ps.setString(1,turno.getHoraInicio());
            ps.setString(2,  turno.getHoraSalida());
            ps.setString(3, turno.getDescripcion());
            ps.setInt(4,turno.getID()); 
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("error:"+e.getMessage() );
            //estos errores guardar ennun archivo
        }
    }
        //Eliminar  un turno
    public void eliminarTurno(int id) {
        try (java.sql.Connection connection= connectToDB()) {
            PreparedStatement ps = null;
            //Statement statement = connection.createStatement();
            String query = "delete from usuario where id =? ";///ojo con el where
            ps = connection.prepareStatement(query);
            ps.setInt(1, id);
 
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
 



}


 
