/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Turno.modelos;

/**
 *
 * @author mireya
 */
public class Turno {
    private int ID;
    private String horaInicio;
     private String horaSalida;
      private String Descripcion;

    public Turno(String horaInicio, String horaSalida, String Descripcion) {
        this.horaInicio = horaInicio;
        this.horaSalida = horaSalida;
        this.Descripcion = Descripcion;
    }
      

    public Turno(int ID, String horaInicio, String horaSalida, String Descripcion) {
        this.ID = ID;
        this.horaInicio = horaInicio;
        this.horaSalida = horaSalida;
        this.Descripcion = Descripcion;
    }
      
      

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(String horaInicio) {
        this.horaInicio = horaInicio;
    }

    public String getHoraSalida() {
        return horaSalida;
    }

    public void setHoraSalida(String horaSalida) {
        this.horaSalida = horaSalida;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

   

      

    
      
      
}
 

