/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UI.Turno;

import java.sql.Connection;
import java.sql.DriverManager;


/**
 *
 * @author mireya
 */
public class UIConexion {
   
    
    public Connection connectToDB() {
		Connection connection = null;
		try {
			
                        
                        String host="ec2-54-247-118-139.eu-west-1.compute.amazonaws.com";
                        String Database= "da5le235ku988s";
                        String User= "unzpaymzkqbfis";
                        String Password="8391b1e14a09b25bd8c4de7ff708595bcd477ce666ae267b98d27d99f10bf62d";
                        
			connection = DriverManager.getConnection("jdbc:postgresql://"+host+":5432/"+Database,User,Password );
			if (connection != null) {
				System.out.println("Se estableció la conexión :)");
		}
		} catch (Exception e) {
			// TODO: handle exception
                        System.out.println("Error al conectar a la base.");
			e.printStackTrace();
		}finally {
			return connection;
		}
		
	}

    
    

    
}


